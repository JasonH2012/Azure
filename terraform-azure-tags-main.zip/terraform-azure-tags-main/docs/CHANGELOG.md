# 1.0.0 (2022-08-12)


### Bug Fixes

* **ci/cd:** test pipeline trigger ([a3db308](https://git.atosone.com/developers/siemens-azure-tags/commit/a3db308bb9b66137b8d013f2c7dc79c98cee2ca5))


### Features

* **docs:** Include list of required fields in readme ([216e20c](https://git.atosone.com/developers/siemens-azure-tags/commit/216e20ce860ea0b4a226713a95846432d0ef5cda))
* **module:** Initialzed repo with required files and tagging module ([ddf6830](https://git.atosone.com/developers/siemens-azure-tags/commit/ddf6830d7b31c382cd98d8f29435f721d8f065bd))
