# terraform-azure-tags
This Terraform module allows to set the tags required in the Azure setup for Siemens. It will also check that all required input is present by validating the data passed in.
The required fields include:
* ciOwnedBy
* escalationManagerIncident
* escalationManagerSupport


<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14.0 |

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_tags"></a> [tags](#input\_tags) | A mapping of tags to assign to the resource. | `map(any)` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_tags"></a> [tags](#output\_tags) | The tags formed by merging the default set and tags provided in the variables. |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
