from email.headerregistry import Group
import requests
import json
from os import getenv
import subprocess
import os

GIT_BASE_URL = "https://git.atosone.com/"
GROUPS = "Developers"
GITHUB_WORKSPACE = getenv('GITHUB_WORKSPACE', '')


def get_project_id(group_projects_list, repository):
    """ Fetch Project name from the json data (project_url) 
    and return project name
    """
    project_id = ""
    if group_projects_list:
        for project in group_projects_list:
            if project['path_with_namespace'] == GROUPS.lower() + "/" + repository:
                project_id = project['id']
                print(project_id)

    return project_id


def get_gitlab_group_projects_list(GIT_BASE_URL, headers):
    """Get Project list from GitLab groups using api"""

    api_url = GIT_BASE_URL + "api/v4/groups/" + GROUPS + "/projects?per_page=100"

    payload = json.dumps({
        "visibility": "internal"
    })

    response = requests.request("GET", api_url, headers=headers, data=payload)
    return response


def get_trigger_pipeline_token(url, headers, project_id):
    trigger_token = ""

    pipeline_trigger = url + "api/v4/projects/" + project_id + "/triggers"

    response = requests.request("GET", pipeline_trigger, headers=headers)
    if response.status_code == 200:
        trigger_token_list = response.json()
        print("trigger_token_list", trigger_token_list)
        if trigger_token_list and len(trigger_token_list) >= 1:
            trigger_token = trigger_token_list[0]['token']
           
        
    else:        
        print("token not found")
   

    return trigger_token


def create_trigger_pipeline_token(url, headers, project_id):
    create_trigger_token_url = url + "api/v4/projects/" + project_id + "/triggers"

    payload = json.dumps({
        "description": "trigger_pipeline"
    })
    response = requests.request(
        
        "POST", create_trigger_token_url, headers=headers, data=payload)
    return response

def set_github_env(project_id,trigger_token):
    env_file = os.getenv('GITHUB_ENV', "") 
    TOKEN = "TRIGGER_TOKEN="+  trigger_token + "\n"
    PROJECT_ID= "project_id=" + project_id
    with open(env_file, "a") as myfile:        
        myfile.write(TOKEN)
        myfile.write(PROJECT_ID)


def trigger_pipeline(url, headers, project_id, trigger_token):
    task = subprocess.run(
        ["ls", GITHUB_WORKSPACE+"/to_deploy"], stdout=subprocess.PIPE)
    # output = subprocess.run(["/bin/bash", "scripts/trigger_pipeline.sh", project_id, trigger_token],
    #                         check=True, capture_output=True, text=True).stdout


def main():
    project_name_list = []
    trigger_token = ""
    GITHUB_REPOSITORY = getenv(
        'GITHUB_REPOSITORY', 'GB-LON-SIEMENS-AUTOMATION/siemens-azure-resourcegroup')
    repository = GITHUB_REPOSITORY.split('/')[-1]

    GITHUB_WORKSPACE = getenv(
        'GITHUB_WORKSPACE', '')

    GITLAB_TOKEN = getenv('GITLAB_TOKEN', 'glpat-Ymbu1MQFx1AZ7sDqHxVM')
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + GITLAB_TOKEN
    }
    project_list_response = get_gitlab_group_projects_list(
        GIT_BASE_URL, headers)

    if project_list_response.status_code == 200:
        group_projects_list = project_list_response.json()
        if group_projects_list:
            project_id = str(get_project_id(group_projects_list, repository))
            #print(project_id)
            trigger_token = get_trigger_pipeline_token(
                GIT_BASE_URL, headers, project_id)           
            
            if (not trigger_token):
                #print("Token not found and creating one ")
                created_trigger_response = create_trigger_pipeline_token(
                    GIT_BASE_URL, headers, project_id)
                print("created_trigger_response ", created_trigger_response)
                if created_trigger_response.status_code == 201:
                    trigger_token = get_trigger_pipeline_token(
                        GIT_BASE_URL, headers, project_id)
                    set_github_env(project_id,trigger_token)
                    return trigger_token

            else:
                set_github_env(project_id,trigger_token)
                # trigger_pipeline(GIT_BASE_URL, headers,
                #                  project_id, trigger_token)
                return trigger_token


if __name__ == '__main__':
    print(main())
