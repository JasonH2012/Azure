import requests
import json


def get_latest_release_tag(url, headers):   

    response = requests.request("GET", url, headers=headers)

    return response


url = "https://api.github.com/repos/A660988/testing-composit/releases/latest"
headers = {
    'Accept': 'application/vnd.github+json',
    'Authorization': 'Bearer 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',
    'Content-Type': 'application/json'
    }

response = get_latest_release_tag(url, headers)
if response.status_code == 200:
    latest_tag = response.json()['tag_name']

        

    


