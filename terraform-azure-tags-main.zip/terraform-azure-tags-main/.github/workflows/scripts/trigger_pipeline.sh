#!/bin/bash

PROJECT_ID=$1
TRIGGER_TOKEN=$2 #'311a6b32e4ae10b4f9706de9b1fc69'
echo $TRIGGER_TOKEN
echo $TRIGGER_ACTION_MESSAGE



GITLAB_BASE_URL="https://git.atosone.com"
echo  "$GITLAB_BASE_URL/api/v4/projects/$PROJECT_ID/trigger/pipeline"

if [[ "$TRIGGER_ACTION_MESSAGE" =~ "provision" ]]; then
    echo "Pipeline trigger for deployment"
    curl --request POST \
    --form token=$TRIGGER_TOKEN \
    --form ref="main" \
    $GITLAB_BASE_URL/api/v4/projects/$PROJECT_ID/trigger/pipeline \
    --form "variables[ACTION_ON_SERVICE]=provision" \
    --form "variables[TERRAFORM_TFVARS_JSON]=test/github/create.json"
    echo $?
    if [ $? -ne 0 ] ; then
         exit 1
    fi

    elif [[ "$TRIGGER_ACTION_MESSAGE" =~ "remove" ]]; then
         echo "remove"
    else
        echo "NOthing"
    
fi 



# curl --request POST \
#      --form token=$TRIGGER_TOKEN \
#      --form ref="main" \
#      $GITLAB_BASE_URL/api/v4/projects/$PROJECT_ID/trigger/pipeline \
#      --form "variables[ACTION_ON_SERVICE]=Yamini" \
#      --form "variables[TERRAFORM_TFVARS_JSON]=package.json"