import requests
import json
from os import getenv

GIT_BASE_URL = "https://git.atosone.com/"
GROUPS = "Developers"


def get_gitlab_project_name(project_url):
    """ Fetch Project name from the json data (project_url) 
    and return project name
    """

    project_name = project_url.split('/')
    project_name_string = project_name[-1].split('.')
    return project_name_string[0]


def get_gitlab_group_projects_list(GIT_BASE_URL, headers):
    """Get Project list from GitLab groups using api"""
    print(headers)

    api_url = GIT_BASE_URL + "api/v4/groups/"+ GROUPS+ "/projects?per_page=100"
    print("api_url for the gitlab groupd projects: - >  ", api_url)

    payload = json.dumps({
        "visibility": "internal"        
    })

    response = requests.request("GET", api_url, headers=headers, data=payload)
    return response

# repository creation in Gitlab if already does not exist


def find_namespace_id(url, headers):
    namespace_id = 0
    
    namespace_url = GIT_BASE_URL + "api/v4/namespaces"
    print("find_namespace_id url: ",namespace_url )
    response = requests.request("GET", namespace_url, headers=headers)

    if response.status_code == 200:
        data = response.json()
        for index in data:
            if index['name'] ==  GROUPS:
                namespace_id = index['id']
                print(namespace_id, type(namespace_id))
    return namespace_id
                
            
        


def create_repository(url, headers, repo_name, namespace_id):
    """repository creation in Gitlab if already does not exist"""
    api_url = url + "api/v4/projects"
    print("api_url: ", api_url)   
        
    payload = json.dumps({
        "visibility": "internal",
        "name": repo_name,        
        "namespace_id": namespace_id,
        "default_branch": "main",
        "initialize_with_readme": "true"
        
    })
    print(payload)
    response = requests.request("POST", api_url, headers=headers, data=payload)
    print("create_repository: ", response)

    return response

# does add in method
def repository_exist_in_gitlab(project_name_list, repository):
    """GitHub repository exist in GitLab or not"""
    if repository in project_name_list:
        return True


def main():
    """ First fetching GITHUB_REPOSITORY from env variable 
        Get GitLab project list 
        and search GITHUB_REPOSITORY in Gitlab projet list 
    """
  # Final return output
    repository_present = False
    project_name_list = []

    GITHUB_REPOSITORY = getenv(
        'GITHUB_REPOSITORY', 'GB-LON-SIEMENS-AUTOMATION/yamini-testing-repo')
    repository = GITHUB_REPOSITORY.split('/')[-1]
    print("repository", repository)
    GITLAB_TOKEN = getenv('GITLAB_TOKEN', 'token')

    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + GITLAB_TOKEN
    }
    project_list_response = get_gitlab_group_projects_list(
        GIT_BASE_URL, headers)

    if project_list_response.status_code == 200:
        group_projects_list = project_list_response.json()

        for project in group_projects_list:
            project_name_list.append(
                get_gitlab_project_name(project['http_url_to_repo']))

        if project_name_list:
            repository_exist = repository_exist_in_gitlab(
                project_name_list, repository)
            if repository_exist:
                print("Repository already exist in gitlab")
                #repository_present = True
            else:
                print("Repository already does not exist in gitlab so creat")
                namespace_id = find_namespace_id(GIT_BASE_URL, headers,)
                repo_creation_response = create_repository(
                    GIT_BASE_URL, headers, repository, namespace_id)
                if repo_creation_response.status_code == 201:
                    print("Creted", repository)
                    repository_present = True

                    if repository_present == True:
                        print(repository_present)
                        return 0
                    else:
                        print(repository_present)
                        return -1


if __name__ == '__main__':
    main()
