# import json
import subprocess

project_id = '17570'
trigger_token = '311a6b32e4ae10b4f9706de9b1fc69'

print("hello")



output = subprocess.run(["/bin/bash", ".github/workflows/scripts/trigger_pipeline.sh", project_id, trigger_token],
                            check=True, capture_output=True, text=True).stdout

print(output)

# from os import getenv, remove

# GITHUB_REPOSITORY = getenv('GITHUB_REPOSITORY', '')
# releaserc_file = getenv('releaserc_file', '')

# f = open(releaserc_file)
# data = json.load(f)
# data['repositoryUrl'] = "https://github.com/" + GITHUB_REPOSITORY


# # import requests

# # GIT_BASE_URL = "https://git.atosone.com/"
# # GROUPS = "Developers"

# # headers = {
# #   'Authorization': 'Bearer glpat-Ymbu1MQFx1AZ7sDqHxVM',
# #   'Content-Type': 'application/json'
# # }

# # def find_namespace_id(url, headers):
# #     namespace_id = 0

# #     namespace_url = GIT_BASE_URL + "api/v4/namespaces"
# #     print("find_namespace_id url: ",namespace_url )
# #     response = requests.request("GET", namespace_url, headers=headers)

# #     if response.status_code == 200:
# #         data = response.json()
# #         for index in data:
# #             print(index['name'])
# #             if index['name'] ==  GROUPS:
# #                 print(index['name'])
# #                 namespace_id = index['id']

# #             else:
# #                 print("faild")

# #     print(namespace_id, type(namespace_id))

# #     return namespace_id


# # id = find_namespace_id(GIT_BASE_URL, headers)
# # print(id)
