#!/bin/bash

if [ -d .github ] 
then
    echo "Directory /path/to/dir exists." 
else
echo "YAmini testing"

fi





# Code for triger GitHub api pipeline 


# curl --request POST \
#   --form token=d94e7339cea0bb227dd495e6bf10a9 \
#   --form ref=main \
#   "https://git.atosone.com/api/v4/projects/17598/trigger/pipeline" \
#   --form "variables[ACTION_ON_SERVICE]=provison" \
#   --form "variables[TERRAFORM_TFVARS_JSON]=/home/yyadav/practice/mpc/siemens-azure-resourcegroup/test/github/create.json"
# # repository_name=$1




# # SUB1='terraform-azurerm'
# # SUB2='siemens-azure'





# # if [[ "$repository_name" =~ "$SUB1".* ]]; then
# #   echo "This repository is teraform module so making changes in README.md file: " $repository_name
# #   sed -i "s@github.com/GB-LON-SIEMENS-AUTOMATION@git::https://git.atosone.com/developers@g" README.md 
# #   elif [[ "$repository_name" =~ "$SUB2".* ]]; then
# #      echo "his repository is teraform service  making changes in README.md file: " $repository_name
# #      sed -i "s@github.com/GB-LON-SIEMENS-AUTOMATION@git::https://git.atosone.com/developers@g" test.tf
# #   else
# #     echo "NO matching found in Repository: "$repository_name
    
# # fi
