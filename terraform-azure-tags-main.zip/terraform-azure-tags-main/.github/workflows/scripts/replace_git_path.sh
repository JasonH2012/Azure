#!/bin/bash
GITLAB_BASE_URL="git.atosone.com/developers/"

# Substring to 
SUB1='terraform-azurerm'
SUB2='siemens-azure'




echo $GITHUB_REPOSITORY
IFS='/' read -r -a array <<< $GITHUB_REPOSITORY
repository_name=${array[-1]} 
echo "GitHub Repository Name: "$repository_name


echo "Cloning the GitLab Repository" 
git clone "https://$GITLAB_USER:$GITLAB_TOKEN@$GITLAB_BASE_URL$repository_name.git" $GITHUB_WORKSPACE/gitlab_project 
 
cd $GITHUB_WORKSPACE/gitlab_project
cp $GITHUB_WORKSPACE/to_deploy/README.md  $GITHUB_WORKSPACE/gitlab_project

SUB1='terraform-azurerm'
SUB2='siemens-azure'
echo  "https://$GITHUB_USER:$GITHUB_TOKEN@github.com/$GITHUB_REPOSITORY.git"
git config --global user.email "yamini.yadav@atos.net"
git config --global user.name "yamini.yadav"

git remote add github "https://oauth2:$GITHUB_TOKEN@github.com/$GITHUB_REPOSITORY.git" #$GITHUB_WORKSPACE/to_deploy/.git


git fetch github
git checkout main
cp $GITHUB_WORKSPACE/to_deploy/README.md  $GITHUB_WORKSPACE/gitlab_project
git add README.md && git commit -m "added README.MD"
git merge github/main -m "Publishing new release" --allow-unrelated-histories || true
#rm -rf .github .releaserc package.json
git rm -rf .github --ignore-unmatch
git rm -rf .releaserc --ignore-unmatch
git rm -rf package.json --ignore-unmatch



if [[ "$repository_name" =~ "$SUB1".* ]]; then
    echo "This repository is teraform module so making changes in README.md file: " $repository_name
    sed -i "s@github.com/GB-LON-SIEMENS-AUTOMATION@git::https://git.atosone.com/developers@g" $GITHUB_WORKSPACE/gitlab_project/README.md 

    elif [[ "$repository_name" =~ "$SUB2".* ]]; then
         echo "This repository is teraform service  making changes in README.md file: " $repository_name
         sed -i "s@github.com/GB-LON-SIEMENS-AUTOMATION@git::https://git.atosone.com/developers@g" $GITHUB_WORKSPACE/gitlab_project/main.tf
    else
        echo "No matching GitHub url found in Repository: "$repository_name
    
fi


git add . 
git diff-index --quiet HEAD  || git commit -m "Cleanup" 

git push

  
