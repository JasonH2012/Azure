#!/bin/bash
GITLAB_BASE_URL="git.atosone.com/developers/"




echo $GITHUB_REPOSITORY
IFS='/' read -r -a array <<< $GITHUB_REPOSITORY
repository_name=${array[-1]} 
echo "GitHub Repository Name: "$repository_name


echo "Cloning the GitLab Repository" 
git clone "https://$GITLAB_USER:$GITLAB_TOKEN@$GITLAB_BASE_URL$repository_name.git" gitlab_project  #"https://yamini.yadav:$GITLAB_TOKEN@git.atosone.com/developers/yamini-testing-repo.git" yamini  
 

ls $GITHUB_WORKSPACE/gitlab_project


echo " Copy all the changes of github repo main branch to gitlab repo and commit and push"   
cd gitlab_project      
git config user.name $GITLAB_USER
git config user.email yamini.yadav@atos.net
cp -R  $GITHUB_WORKSPACE/gitlab_project/test/github/* $GITHUB_WORKSPACE/gitlab_project/test/gitlab
 
git add .
git commit -m "New release changes added"
git push       
